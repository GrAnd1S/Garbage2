#ifndef PARSE_ARGS_H
#define PARSE_ARGS_H
#include "data_source.h"

Filters parse_args(int argc, char *argv[]);

#endif /* PARSE_ARGS_H */
